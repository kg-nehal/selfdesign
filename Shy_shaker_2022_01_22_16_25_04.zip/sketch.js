var room1,room2;
var ghost, ghostAlive;

function preload() {
  ghostAlive = loadAnimation("l0_spriteGhost1.png","l0_spriteGhost2.png","l0_spriteGhost3.png");
}

function setup() {
  createCanvas(400, 400);
  ghost = createSprite(50,180,20,50);
  
  ghost.addAnimation("alive",ghostAlive);

}
function draw() {
  background(220);
  drawSprites();
}